to use make a discord webhook and get a png file
put the webhook in the builder and the img and it shoud generate a file then send to victim and image log them